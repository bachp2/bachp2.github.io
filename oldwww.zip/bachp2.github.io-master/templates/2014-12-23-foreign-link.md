---
layout: post
title: Testing bash applications
date: 2014-01-15 00:18:23
author: sobolevn
categories: bash
short_description: This is an overview post about testing frameworks in bash.
image_preview: https://habracdn.net/habr/images/1469788235/logo.svg?r=2
external_url: https://habrahabr.ru/post/278937/
---
