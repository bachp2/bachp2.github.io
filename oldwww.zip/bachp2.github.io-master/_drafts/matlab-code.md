---
layout: post
title: Compile C code in Matlab
date: 2018-09-03 09:28:23
author: bachp2
categories: 
image_preview: https://avatars2.githubusercontent.com/u/26563478?s=400&v=4
---
Hi all,<br/>
Since this is the first time I'm writing for this blog, an introduction is in order. I am a mechanical engineer student studying at UW Bothell. I intend for this to be my personal blog to share and document my progress in research areas namely the Ocean Sound Project and the Robotics Team in the upcoming NASA Mining Competition 2019. I also enjoy programming as a hobby, and I have some projects that I'd like to share!<br/>
Stay tuned!